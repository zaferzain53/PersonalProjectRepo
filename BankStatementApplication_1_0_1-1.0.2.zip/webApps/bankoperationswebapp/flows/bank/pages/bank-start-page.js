    /*
    Copyright (c) 2018, Oracle and/or its affiliates.
    The Universal Permissive License (UPL), Version 1.0
    */
    define([], function() {
    'use strict';

    var PageModule = function PageModule() {}; 

    PageModule.prototype.getCurentGLPeriods= function() {

    var localDateTime = new Date();

    var year = localDateTime.getUTCFullYear();
    var month = ("0" + (localDateTime.getUTCMonth() + 1)).slice(-2);


    if(month == "01")
    month="Jan";
    else if(month == "02")
    month="Feb";
    else if(month == "03")
    month="Mar";
    else if(month == "04")
    month="Apr";
    else if(month == "05")
    month="May";
    else if(month == "06")
    month="Jun";    
    else if(month == "07")
    month="Jul";
    else if(month == "08")
    month="Aug";
    else if(month == "09")
    month="Sep";
    else if(month == "10")
    month="Oct";
    else if(month == "11")
    month="Nov";
    else if(month == "12")
    month="Dec";

    var monthYear=month + '-' +year;



    // var shortMonthName = new Intl.DateTimeFormat("en-US", { month : "short" }).format;
    // var shortName = shortMonthName(localDateTime-1); 



    return monthYear;

    };



    PageModule.prototype.getPrevGLPeriods= function() {

    var localDateTime = new Date();

    var year = localDateTime.getUTCFullYear();
    var month = ("0" + (localDateTime.getMonth())).slice(-2);

    if(month == "01")
    month="Jan";
    else if(month == "02")
    month="Feb";
    else if(month == "03")
    month="Mar";
    else if(month == "04")
    month="Apr";
    else if(month == "05")
    month="May";
    else if(month == "06")
    month="Jun";    
    else if(month == "07")
    month="Jul";
    else if(month == "08")
    month="Aug";
    else if(month == "09")
    month="Sep";
    else if(month == "10")
    month="Oct";
    else if(month == "11")
    month="Nov";
    else if(month == "12")
    month="Dec";

    var monthYear=month + '-' +year;

    return monthYear;

    };

    PageModule.prototype.getCurrentUTCDate = function() {

    var localDateTime = new Date();

    localDateTime = new Date(localDateTime.setDate(localDateTime.getDate() - 1));

    var year = localDateTime.getUTCFullYear();
    var month = ("0" + (localDateTime.getUTCMonth() + 1)).slice(-2);
    var day = ("0" + (localDateTime.getDate())).slice(-2);
    var hours = "00"; //("0" + localDateTime.getUTCHours()).slice(-2);
    var minutes = "00"; //("0" + localDateTime.getUTCMinutes()).slice(-2);
    var seconds = "00"; //("0" + localDateTime.getUTCSeconds()).slice(-2);
    var utcDateTime = year + '-' + month + '-' + day + 'T' + hours + ':' +
    minutes + ":" + seconds;

    return utcDateTime;
    };

    PageModule.prototype.findMDBankName = function(list,value) {

    return  list.find(record => record.BANKACCOUNTNUMBER === value).BANKNAME;

    }

    PageModule.prototype.getSysdate = function () {

    var d = new Date();
    var dt = new Date(d.getFullYear());
    var n = d.toLocaleString();

    var sysdate=+d.getMonth().toString()+' '+d.getDate()+','+d.getFullYear();
    console.log("local date: "+d);
    console.log("local date: "+dt);
    console.log("local date: "+n);
    console.log("local date: "+sysdate);
    //September 17, 2020n

    var localDateTime = new Date();

    localDateTime = new Date(localDateTime.setDate(localDateTime.getDate() - 1));

    var year = localDateTime.getUTCFullYear();
    var month = ("0" + (localDateTime.getUTCMonth() + 1)).slice(-2);
    var day = ("0" + (localDateTime.getDate())).slice(-2);
    var hours = ("0" + localDateTime.getUTCHours()).slice(-2);
    var minutes = ("0" + localDateTime.getUTCMinutes()).slice(-2);
    var seconds = ("0" + localDateTime.getUTCSeconds()).slice(-2);
    var mSeconds = ("0" + localDateTime.getUTCMilliseconds());
    var utcDateTime = year+month+day+hours+minutes+seconds+mSeconds;

    console.log("local date: "+localDateTime);
    console.log("local date: "+utcDateTime);

    return utcDateTime;
    };

    PageModule.prototype.payloadMDData = function (RESTData) {

    console.log("meher RESTData:"+JSON.stringify(RESTData));

    var amount = 0;
    for(var j in RESTData){

    amount= amount + RESTData[j].AMOUNT;

    }
    console.log("meher:"+amount);

    return amount;
    };

    PageModule.prototype.showLoader = function () {
    $(".loadingBackground").css("display", "block");
    $(".circularLoading").css("display", "block");
    };

    PageModule.prototype.hideLoader = function () {
    $(".loadingBackground").css("display", "none");
    $(".circularLoading").css("display", "none");
    };

    return PageModule;
    });


