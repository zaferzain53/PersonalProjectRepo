/*
  Copyright (c) 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define([], function () {
  'use strict';

  var AppModule = function AppModule() {};


    AppModule.prototype.isFormValid=function(form){    
    var tracker = document.getElementById(form);   


    if(tracker.valid === "valid"){
    return true;
    }
    else{
    tracker.showMessages();
    tracker.focusOn("@firstInvalidShown");
    return false;
    }   


    };


  return AppModule;
});